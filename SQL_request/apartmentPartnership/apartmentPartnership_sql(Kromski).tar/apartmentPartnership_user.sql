﻿--Данный файл представляет возможости пользователя user_%USER_NAME%

USE apartmentPartnership
EXEC allInfoAboutUser
